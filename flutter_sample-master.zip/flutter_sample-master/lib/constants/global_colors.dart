import 'package:flutter/material.dart';

//Colors
Color bgMain = Color(0xFF121212);
